// photo-app.jsx — edit-over-photo editor.
//
// One inline SVG that layers:
//   1) the photo (with a colour-grade filter)
//   2) atmospheric overlays (extra clouds, sun glow, haze, light leak)
//   3) finishing layer (gradient darken for UI text, vignette, grain)
// PNG export inlines the photo as a data URL so the rasterised SVG is
// not cross-origin tainted, then upscales via canvas.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "preset": "original",
  "exposure": 0,
  "contrast": 1.0,
  "saturation": 1.05,
  "warmth": 0,
  "blur": 0,
  "extraClouds": 0,
  "sunOn": false,
  "sunX": 0.18,
  "sunY": 0.22,
  "sunSize": 0.45,
  "sunIntensity": 0.35,
  "haze": 0,
  "lightLeak": "none",
  "darkenBottom": 0,
  "vignette": 0.08,
  "grain": 0.04,
  "tintColor": "#000000",
  "tintAmount": 0,
  "aspect": "native",
  "panX": 0.5,
  "panY": 0.5,
  "exportScale": 2
}/*EDITMODE-END*/;

const PHOTO_SRC  = 'assets/photo.jpg';
const PHOTO_W = 1199;
const PHOTO_H = 856;

// ── Color grade presets ─────────────────────────────────────────────────────
// Each preset is a delta over the live sliders — applied as base values you
// can then tweak further. Picking one overwrites exposure/contrast/sat/warm.

const GRADES = {
  original:   { name: 'Original',   exposure: 0,     contrast: 1.0,  saturation: 1.05, warmth:  0 },
  vivid:      { name: 'Vivid',      exposure: 0.03,  contrast: 1.15, saturation: 1.30, warmth:  0.05 },
  warm:       { name: 'Warm',       exposure: 0.05,  contrast: 1.08, saturation: 1.10, warmth:  0.35 },
  golden:     { name: 'Golden',     exposure: 0.02,  contrast: 1.20, saturation: 1.20, warmth:  0.60 },
  cool:       { name: 'Cool',       exposure: 0.00,  contrast: 1.10, saturation: 1.00, warmth: -0.30 },
  twilight:   { name: 'Twilight',   exposure: -0.12, contrast: 1.18, saturation: 0.85, warmth: -0.45 },
  cinematic:  { name: 'Cinematic',  exposure: -0.05, contrast: 1.25, saturation: 1.05, warmth:  0.10 },
  faded:      { name: 'Faded',      exposure: 0.04,  contrast: 0.85, saturation: 0.80, warmth:  0.05 },
  mono:       { name: 'B&W',        exposure: 0.02,  contrast: 1.20, saturation: 0,    warmth:  0 },
};

const LIGHT_LEAKS = {
  none:        { name: 'None' },
  topLeft:     { name: 'Top-left',     cx: '-5%',  cy: '-5%',  color: '#ffb37a', alpha: 0.45, r: '70%' },
  topRight:    { name: 'Top-right',    cx: '105%', cy: '-5%',  color: '#ffd28a', alpha: 0.40, r: '70%' },
  bottomLeft:  { name: 'Bottom-left',  cx: '-5%',  cy: '105%', color: '#ff7f5f', alpha: 0.35, r: '70%' },
  bottomRight: { name: 'Bottom-right', cx: '105%', cy: '105%', color: '#ffb27a', alpha: 0.45, r: '70%' },
};

const ASPECTS = {
  native: { name: 'Native (1199×856)', w: 1199, h: 856 },
  '16:9': { name: '16:9 · Desktop',   w: 1920, h: 1080 },
  '21:9': { name: '21:9 · Ultrawide', w: 2520, h: 1080 },
  '1:1':  { name: '1:1 · Square',     w: 1080, h: 1080 },
  '9:16': { name: '9:16 · Mobile',    w: 1080, h: 1920 },
  '4:3':  { name: '4:3',              w: 1600, h: 1200 },
};

// ── Helpers ─────────────────────────────────────────────────────────────────

// Compute a viewBox into the source photo so that, given an output aspect
// ratio, we crop to that aspect ratio, panning around the photo by pan{X,Y}.
function cropViewBox(outW, outH, panX, panY) {
  const photoAR = PHOTO_W / PHOTO_H;
  const outAR = outW / outH;
  let w, h;
  if (outAR > photoAR) {
    // Output is wider than photo → use full photo width, crop top/bottom.
    w = PHOTO_W; h = PHOTO_W / outAR;
  } else {
    // Output is taller/narrower → use full photo height, crop sides.
    h = PHOTO_H; w = PHOTO_H * outAR;
  }
  const maxX = PHOTO_W - w;
  const maxY = PHOTO_H - h;
  const x = maxX * panX;
  const y = maxY * panY;
  return { x, y, w, h, photoW: PHOTO_W, photoH: PHOTO_H };
}

// Component transfer for exposure + contrast. Constructs SVG fragments.
function ExposureContrastFilter({ exposure, contrast, saturation, warmth, blur }) {
  // For contrast c and exposure e: out = c * in + (1-c)/2 + e
  const slope = contrast;
  const intercept = (1 - contrast) / 2 + exposure;
  const wr = 1 + warmth * 0.20;
  const wb = 1 - warmth * 0.20;
  const wg = 1 + warmth * 0.03;
  const warmthMatrix = [
    wr, 0, 0, 0, 0,
    0, wg, 0, 0, 0,
    0, 0, wb, 0, 0,
    0, 0, 0, 1, 0,
  ].join(' ');
  return (
    <filter id="grade" x="-2%" y="-2%" width="104%" height="104%" colorInterpolationFilters="sRGB">
      <feComponentTransfer>
        <feFuncR type="linear" slope={slope} intercept={intercept} />
        <feFuncG type="linear" slope={slope} intercept={intercept} />
        <feFuncB type="linear" slope={slope} intercept={intercept} />
      </feComponentTransfer>
      <feColorMatrix type="saturate" values={saturation} />
      <feColorMatrix type="matrix" values={warmthMatrix} />
      {blur > 0 && <feGaussianBlur stdDeviation={blur} />}
    </filter>
  );
}

function CloudsOverlay({ amount, view }) {
  if (amount <= 0) return null;
  const thresholdShift = -2.6 + amount * 2.4;
  return (
    <g>
      <defs>
        <filter id="extraCloudA" x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.0035 0.018"
                        numOctaves="3" seed="7" />
          <feColorMatrix values={`0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 5 ${thresholdShift}`} />
          <feGaussianBlur stdDeviation="0.5" />
        </filter>
        <filter id="extraCloudB" x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.006 0.024"
                        numOctaves="4" seed="11" />
          <feColorMatrix values={`0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 4.5 ${thresholdShift - 0.4}`} />
          <feGaussianBlur stdDeviation="0.4" />
        </filter>
        <linearGradient id="cloudMaskGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#fff" stopOpacity="0.5" />
          <stop offset="50%" stopColor="#fff" stopOpacity="0.95" />
          <stop offset="75%" stopColor="#fff" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <mask id="cloudMask">
          <rect x={view.x} y={view.y} width={view.w} height={view.h} fill="url(#cloudMaskGrad)" />
        </mask>
      </defs>
      <g mask="url(#cloudMask)" style={{ opacity: Math.min(1, amount * 1.1), mixBlendMode: 'screen' }}>
        <rect x="0" y="0" width={view.photoW} height={view.photoH} fill="#fff" filter="url(#extraCloudA)" />
        <rect x="0" y="0" width={view.photoW} height={view.photoH} fill="#fff" filter="url(#extraCloudB)"
              style={{ opacity: 0.6 }} />
      </g>
    </g>
  );
}

function SunGlow({ on, x, y, size, intensity, color, view }) {
  if (!on || intensity <= 0) return null;
  const cx = view.x + view.w * x;
  const cy = view.y + view.h * y;
  const r = size * Math.max(view.w, view.h);
  return (
    <g>
      <defs>
        <radialGradient id="sunRG" cx="50%" cy="50%" r="50%">
          <stop offset="0%"  stopColor={color} stopOpacity={intensity} />
          <stop offset="35%" stopColor={color} stopOpacity={intensity * 0.45} />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cy} r={r} fill="url(#sunRG)"
              style={{ mixBlendMode: 'screen' }} />
    </g>
  );
}

function Haze({ amount, view }) {
  if (amount <= 0) return null;
  return (
    <g>
      <defs>
        <linearGradient id="hazeGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#e8f0f6" stopOpacity="0" />
          <stop offset="55%"  stopColor="#e8f0f6" stopOpacity={amount * 0.7} />
          <stop offset="68%"  stopColor="#e8f0f6" stopOpacity={amount * 0.4} />
          <stop offset="100%" stopColor="#e8f0f6" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect x={view.x} y={view.y} width={view.w} height={view.h} fill="url(#hazeGrad)" />
    </g>
  );
}

function LightLeak({ id, view }) {
  const leak = LIGHT_LEAKS[id];
  if (!leak || id === 'none') return null;
  return (
    <g>
      <defs>
        <radialGradient id="leakG" cx={leak.cx} cy={leak.cy} r={leak.r}>
          <stop offset="0%"  stopColor={leak.color} stopOpacity={leak.alpha} />
          <stop offset="60%" stopColor={leak.color} stopOpacity={leak.alpha * 0.3} />
          <stop offset="100%" stopColor={leak.color} stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect x={view.x} y={view.y} width={view.w} height={view.h} fill="url(#leakG)"
            style={{ mixBlendMode: 'screen' }} />
    </g>
  );
}

function DarkenBottom({ amount, view }) {
  if (amount <= 0) return null;
  return (
    <g>
      <defs>
        <linearGradient id="darkenG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#000" stopOpacity="0" />
          <stop offset="55%" stopColor="#000" stopOpacity="0" />
          <stop offset="100%" stopColor="#000" stopOpacity={amount} />
        </linearGradient>
      </defs>
      <rect x={view.x} y={view.y} width={view.w} height={view.h} fill="url(#darkenG)" />
    </g>
  );
}

function Tint({ color, amount, view }) {
  if (amount <= 0) return null;
  return (
    <rect x={view.x} y={view.y} width={view.w} height={view.h} fill={color}
          style={{ opacity: amount, mixBlendMode: 'multiply' }} />
  );
}

function Vignette({ amount, view }) {
  if (amount <= 0) return null;
  return (
    <g>
      <defs>
        <radialGradient id="vigG" cx="50%" cy="50%" r="70%">
          <stop offset="55%"  stopColor="#000" stopOpacity="0" />
          <stop offset="100%" stopColor="#000" stopOpacity={amount} />
        </radialGradient>
      </defs>
      <rect x={view.x} y={view.y} width={view.w} height={view.h} fill="url(#vigG)" />
    </g>
  );
}

function Grain({ amount, view }) {
  if (amount <= 0) return null;
  return (
    <g>
      <defs>
        <filter id="grainF" x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="1.6" numOctaves="2" seed="13" />
          <feColorMatrix values="0 0 0 0 1
                                 0 0 0 0 1
                                 0 0 0 0 1
                                 0 0 0 0.5 -0.25" />
        </filter>
      </defs>
      <rect x={view.x} y={view.y} width={view.w} height={view.h} filter="url(#grainF)"
            style={{ mixBlendMode: 'overlay', opacity: amount }} />
    </g>
  );
}

// ── Scene ───────────────────────────────────────────────────────────────────

function PhotoScene({ t, svgRef, photoHref = PHOTO_SRC }) {
  const aspect = ASPECTS[t.aspect];
  const view = cropViewBox(aspect.w, aspect.h, t.panX, t.panY);
  const viewBox = `${view.x} ${view.y} ${view.w} ${view.h}`;

  return (
    <svg ref={svgRef}
         xmlns="http://www.w3.org/2000/svg"
         xmlnsXlink="http://www.w3.org/1999/xlink"
         viewBox={viewBox}
         preserveAspectRatio="xMidYMid slice"
         style={{ display: 'block', width: '100%', height: '100%' }}>
      <defs>
        <ExposureContrastFilter
          exposure={t.exposure}
          contrast={t.contrast}
          saturation={t.saturation}
          warmth={t.warmth}
          blur={t.blur}
        />
      </defs>
      {/* Photo, color-graded */}
      <image href={photoHref} xlinkHref={photoHref}
             x="0" y="0" width={PHOTO_W} height={PHOTO_H}
             preserveAspectRatio="xMidYMid slice"
             filter="url(#grade)" />
      {/* Atmosphere */}
      <CloudsOverlay amount={t.extraClouds} view={view} />
      <Haze amount={t.haze} view={view} />
      <SunGlow on={t.sunOn} x={t.sunX} y={t.sunY}
               size={t.sunSize} intensity={t.sunIntensity}
               color="#ffe1a8" view={view} />
      <LightLeak id={t.lightLeak} view={view} />
      {/* Finishing */}
      <Tint color={t.tintColor} amount={t.tintAmount} view={view} />
      <DarkenBottom amount={t.darkenBottom} view={view} />
      <Vignette amount={t.vignette} view={view} />
      <Grain amount={t.grain} view={view} />
    </svg>
  );
}

// ── Export ──────────────────────────────────────────────────────────────────

let __photoDataURL = null;
async function getPhotoDataURL() {
  if (__photoDataURL) return __photoDataURL;
  const res = await fetch(PHOTO_SRC);
  const blob = await res.blob();
  __photoDataURL = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
  return __photoDataURL;
}

async function exportPNG({ svgEl, outW, outH, filename }) {
  const dataURL = await getPhotoDataURL();
  const clone = svgEl.cloneNode(true);
  // Replace photo href/xlink:href on the cloned <image>
  clone.querySelectorAll('image').forEach((img) => {
    img.setAttribute('href', dataURL);
    img.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', dataURL);
  });
  clone.setAttribute('width', outW);
  clone.setAttribute('height', outH);
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  clone.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');

  const xml = new XMLSerializer().serializeToString(clone);
  const blob = new Blob([xml], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const img = new Image();
  await new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = reject;
    img.src = url;
  });

  const canvas = document.createElement('canvas');
  canvas.width = outW;
  canvas.height = outH;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0, outW, outH);
  URL.revokeObjectURL(url);

  await new Promise((resolve) => {
    canvas.toBlob((b) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(b);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      resolve();
    }, 'image/png', 1.0);
  });
}

// ── App ─────────────────────────────────────────────────────────────────────

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const svgRef = React.useRef(null);
  const [exporting, setExporting] = React.useState(false);
  const [lastInfo, setLastInfo] = React.useState('');

  // Apply a grade preset on selection — overwrites the four manual sliders.
  const applyPreset = (k) => {
    const g = GRADES[k];
    setTweak({
      preset: k,
      exposure: g.exposure,
      contrast: g.contrast,
      saturation: g.saturation,
      warmth: g.warmth,
    });
  };

  const aspect = ASPECTS[t.aspect];
  const outW = Math.round(aspect.w * t.exportScale);
  const outH = Math.round(aspect.h * t.exportScale);

  const onExport = async () => {
    if (!svgRef.current || exporting) return;
    setExporting(true);
    try {
      const filename = `meadow_${t.preset}_${outW}x${outH}.png`;
      await exportPNG({ svgEl: svgRef.current, outW, outH, filename });
      setLastInfo(`${outW.toLocaleString()}×${outH.toLocaleString()}`);
    } catch (e) {
      console.error(e);
      alert('Export failed: ' + e.message);
    } finally {
      setExporting(false);
    }
  };

  // grade chip palette = warmth swatches with the photo greens
  const gradeChips = Object.keys(GRADES).map((k) => {
    const g = GRADES[k];
    const warm = g.warmth;
    const hue = warm >= 0 ? `oklch(0.78 0.12 ${60 - warm * 20})` : `oklch(0.78 0.12 ${230 + warm * 30})`;
    const sat = g.saturation;
    const green = sat === 0 ? '#888' : `oklch(0.68 ${0.18 * Math.min(1.4, sat)} 140)`;
    const sky = sat === 0 ? '#bbb' : hue;
    return [sky, green, k === 'mono' ? '#444' : (g.exposure < 0 ? '#202028' : '#fff')];
  });
  const gradeKeys = Object.keys(GRADES);
  const currentChip = gradeChips[gradeKeys.indexOf(t.preset)] || gradeChips[0];

  return (
    <div className="stage">
      <div className="frame" style={{ aspectRatio: `${aspect.w} / ${aspect.h}` }}>
        <PhotoScene t={t} svgRef={svgRef} />
      </div>

      {(exporting || lastInfo) && (
        <div className="export-badge">
          {exporting
            ? <span><span className="spinner" /> Rendering…</span>
            : <span>Saved · {lastInfo} px</span>}
        </div>
      )}

      <TweaksPanel title="Edit photo">
        <TweakSection label="Grade" />
        <TweakColor
          label="Preset"
          value={currentChip}
          options={gradeChips}
          onChange={(palette) => {
            const idx = gradeChips.findIndex((p) => p[0] === palette[0] && p[1] === palette[1]);
            if (idx >= 0) applyPreset(gradeKeys[idx]);
          }}
        />
        <div className="readout">{GRADES[t.preset]?.name || ''}</div>

        <TweakSlider label="Exposure" value={Number(t.exposure.toFixed(2))}
                     min={-0.4} max={0.4} step={0.02}
                     onChange={(v) => setTweak('exposure', v)} />
        <TweakSlider label="Contrast" value={Number(t.contrast.toFixed(2))}
                     min={0.6} max={1.6} step={0.02}
                     onChange={(v) => setTweak('contrast', v)} />
        <TweakSlider label="Saturation" value={Number(t.saturation.toFixed(2))}
                     min={0} max={2} step={0.05}
                     onChange={(v) => setTweak('saturation', v)} />
        <TweakSlider label="Warmth" value={Number(t.warmth.toFixed(2))}
                     min={-1} max={1} step={0.05}
                     onChange={(v) => setTweak('warmth', v)} />
        <TweakSlider label="Blur (defocus)" value={t.blur}
                     min={0} max={30} step={0.5} unit="px"
                     onChange={(v) => setTweak('blur', v)} />

        <TweakSection label="Atmosphere" />
        <TweakSlider label="Extra clouds" value={Math.round(t.extraClouds * 100)}
                     min={0} max={100} step={5} unit="%"
                     onChange={(v) => setTweak('extraClouds', v / 100)} />
        <TweakSlider label="Haze" value={Math.round(t.haze * 100)}
                     min={0} max={80} step={5} unit="%"
                     onChange={(v) => setTweak('haze', v / 100)} />
        <TweakToggle label="Sun glow" value={t.sunOn}
                     onChange={(v) => setTweak('sunOn', v)} />
        {t.sunOn && (
          <>
            <TweakSlider label="Sun ←→" value={Math.round(t.sunX * 100)}
                         min={0} max={100} step={5} unit="%"
                         onChange={(v) => setTweak('sunX', v / 100)} />
            <TweakSlider label="Sun ↑↓" value={Math.round(t.sunY * 100)}
                         min={0} max={100} step={5} unit="%"
                         onChange={(v) => setTweak('sunY', v / 100)} />
            <TweakSlider label="Sun size" value={Math.round(t.sunSize * 100)}
                         min={10} max={120} step={5} unit="%"
                         onChange={(v) => setTweak('sunSize', v / 100)} />
            <TweakSlider label="Sun glow" value={Math.round(t.sunIntensity * 100)}
                         min={0} max={100} step={5} unit="%"
                         onChange={(v) => setTweak('sunIntensity', v / 100)} />
          </>
        )}
        <TweakSelect label="Light leak" value={t.lightLeak}
                     options={Object.keys(LIGHT_LEAKS).map((k) => ({ value: k, label: LIGHT_LEAKS[k].name }))}
                     onChange={(v) => setTweak('lightLeak', v)} />

        <TweakSection label="Finish" />
        <TweakColor label="Tint"
                    value={t.tintColor}
                    options={['#000000', '#1d4ed8', '#7c3aed', '#dc2626', '#059669', '#f59e0b']}
                    onChange={(v) => setTweak('tintColor', v)} />
        <TweakSlider label="Tint amount" value={Math.round(t.tintAmount * 100)}
                     min={0} max={60} step={5} unit="%"
                     onChange={(v) => setTweak('tintAmount', v / 100)} />
        <TweakSlider label="Darken bottom" value={Math.round(t.darkenBottom * 100)}
                     min={0} max={80} step={5} unit="%"
                     onChange={(v) => setTweak('darkenBottom', v / 100)} />
        <TweakSlider label="Vignette" value={Math.round(t.vignette * 100)}
                     min={0} max={50} step={2} unit="%"
                     onChange={(v) => setTweak('vignette', v / 100)} />
        <TweakSlider label="Grain" value={Math.round(t.grain * 100)}
                     min={0} max={20} step={1} unit="%"
                     onChange={(v) => setTweak('grain', v / 100)} />

        <TweakSection label="Crop" />
        <TweakSelect label="Aspect" value={t.aspect}
                     options={Object.keys(ASPECTS).map((k) => ({ value: k, label: ASPECTS[k].name }))}
                     onChange={(v) => setTweak('aspect', v)} />
        <TweakSlider label="Pan ←→" value={Math.round(t.panX * 100)}
                     min={0} max={100} step={5} unit="%"
                     onChange={(v) => setTweak('panX', v / 100)} />
        <TweakSlider label="Pan ↑↓" value={Math.round(t.panY * 100)}
                     min={0} max={100} step={5} unit="%"
                     onChange={(v) => setTweak('panY', v / 100)} />

        <TweakSection label="Export" />
        <TweakSlider label="Resolution" value={t.exportScale}
                     min={1} max={5} step={0.5} unit="×"
                     onChange={(v) => setTweak('exportScale', v)} />
        <div className="readout">→ {outW.toLocaleString()} × {outH.toLocaleString()} px</div>
        <TweakButton label={exporting ? 'Rendering…' : 'Download PNG'}
                     onClick={onExport} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
