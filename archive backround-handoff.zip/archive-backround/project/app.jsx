// app.jsx — wires the Scene to the TweaksPanel and adds hi-res PNG export.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "todKey": "day",
  "hillKey": "rolling",
  "aspect": "16:9",
  "cloudDensity": 0.6,
  "sunOn": true,
  "vignette": 0.16,
  "grain": 0.05,
  "exportScale": 2
}/*EDITMODE-END*/;

// Convert hex/rgb-ish color tokens into a label we can show next to the swatch.
function todLabel(k) { return TOD_PRESETS[k].name; }
function compLabel(k) { return HILL_COMPOSITIONS[k].name; }

// Serialise the inline SVG (no external assets) into a Blob, then load it into
// an <img>, then draw it onto a canvas at scale×base. Filters like
// feTurbulence rasterise correctly through this path in Chrome/Safari.
async function exportPNG({ svgEl, baseW, baseH, scale, filename }) {
  // Clone so we can set explicit width/height attrs on the export copy
  // without disturbing the live preview.
  const clone = svgEl.cloneNode(true);
  const targetW = Math.round(baseW * scale);
  const targetH = Math.round(baseH * scale);
  clone.setAttribute('width', targetW);
  clone.setAttribute('height', targetH);
  clone.setAttribute('viewBox', `0 0 ${baseW} ${baseH}`);
  // Inline xmlns just in case (SVG outside DOM)
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  const xml = new XMLSerializer().serializeToString(clone);
  const blob = new Blob([xml], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const img = new Image();
  img.crossOrigin = 'anonymous';
  await new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = reject;
    img.src = url;
  });

  const canvas = document.createElement('canvas');
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0, targetW, targetH);
  URL.revokeObjectURL(url);

  await new Promise((resolve) => {
    canvas.toBlob((pngBlob) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(pngBlob);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      resolve();
    }, 'image/png', 1.0);
  });
}

function ExportStatusBadge({ exporting, lastSize }) {
  if (!exporting && !lastSize) return null;
  return (
    <div className="export-badge">
      {exporting
        ? <span><span className="spinner" /> Rendering…</span>
        : <span>Saved · {lastSize}</span>}
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const svgRef = React.useRef(null);
  const [exporting, setExporting] = React.useState(false);
  const [lastSize, setLastSize] = React.useState('');

  const aspect = ASPECTS[t.aspect];
  const targetW = Math.round(aspect.w * t.exportScale);
  const targetH = Math.round(aspect.h * t.exportScale);

  const onExport = async () => {
    if (!svgRef.current || exporting) return;
    setExporting(true);
    try {
      const todName = TOD_PRESETS[t.todKey].name.toLowerCase().replace(/\s+/g, '-');
      const compName = HILL_COMPOSITIONS[t.hillKey].name.toLowerCase();
      const filename = `landscape_${compName}_${todName}_${targetW}x${targetH}.png`;
      await exportPNG({
        svgEl: svgRef.current,
        baseW: aspect.w,
        baseH: aspect.h,
        scale: t.exportScale,
        filename,
      });
      setLastSize(`${targetW.toLocaleString()}×${targetH.toLocaleString()}`);
    } catch (e) {
      console.error('Export failed', e);
      alert('Export failed: ' + e.message);
    } finally {
      setExporting(false);
    }
  };

  // Curated tod chips — show a tiny palette per option
  const todChips = Object.keys(TOD_PRESETS).map((k) => {
    const p = TOD_PRESETS[k];
    return [p.sky[0].c, p.sky[Math.floor(p.sky.length / 2)].c,
            p.sky[p.sky.length - 1].c, p.hillFront];
  });
  const todKeys = Object.keys(TOD_PRESETS);
  const currentTodPalette = todChips[todKeys.indexOf(t.todKey)];

  return (
    <div className="stage">
      <div className="frame" style={{ aspectRatio: `${aspect.w} / ${aspect.h}` }}>
        <Scene
          todKey={t.todKey}
          hillKey={t.hillKey}
          aspect={t.aspect}
          cloudDensity={t.cloudDensity}
          sunOn={t.sunOn}
          vignette={t.vignette}
          grain={t.grain}
          svgRef={svgRef}
        />
      </div>

      <ExportStatusBadge exporting={exporting} lastSize={lastSize} />

      <TweaksPanel title="Background">
        <TweakSection label="Mood" />
        <TweakColor
          label="Time of day"
          value={currentTodPalette}
          options={todChips}
          onChange={(palette) => {
            const idx = todChips.findIndex((p) => p[0] === palette[0]);
            if (idx >= 0) setTweak('todKey', todKeys[idx]);
          }}
        />
        <div className="tod-name">{todLabel(t.todKey)}</div>

        <TweakSection label="Landscape" />
        <TweakSelect
          label="Hills"
          value={t.hillKey}
          options={Object.keys(HILL_COMPOSITIONS).map((k) => ({
            value: k, label: HILL_COMPOSITIONS[k].name,
          }))}
          onChange={(v) => setTweak('hillKey', v)}
        />
        <TweakSlider
          label="Cloud density"
          value={Math.round(t.cloudDensity * 100)}
          min={0} max={100} step={5} unit="%"
          onChange={(v) => setTweak('cloudDensity', v / 100)}
        />
        <TweakToggle
          label="Sun glow"
          value={t.sunOn}
          onChange={(v) => setTweak('sunOn', v)}
        />

        <TweakSection label="Finish" />
        <TweakSlider
          label="Vignette"
          value={Math.round(t.vignette * 100)}
          min={0} max={40} step={2} unit="%"
          onChange={(v) => setTweak('vignette', v / 100)}
        />
        <TweakSlider
          label="Grain"
          value={Math.round(t.grain * 100)}
          min={0} max={20} step={1} unit="%"
          onChange={(v) => setTweak('grain', v / 100)}
        />

        <TweakSection label="Output" />
        <TweakSelect
          label="Aspect"
          value={t.aspect}
          options={Object.keys(ASPECTS).map((k) => ({ value: k, label: ASPECTS[k].name }))}
          onChange={(v) => setTweak('aspect', v)}
        />
        <TweakSlider
          label="Resolution"
          value={t.exportScale}
          min={1} max={5} step={0.5} unit="×"
          onChange={(v) => setTweak('exportScale', v)}
        />
        <div className="resolution-readout">
          → {targetW.toLocaleString()} × {targetH.toLocaleString()} px
        </div>
        <TweakButton label={exporting ? 'Rendering…' : 'Download PNG'}
                     onClick={onExport} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
