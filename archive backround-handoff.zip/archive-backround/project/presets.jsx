// presets.jsx — color palettes per time of day and hill compositions.
// Each palette also tunes cloud/sun parameters for the mood.

const TOD_PRESETS = {
  day: {
    name: 'Bright Day',
    sky: [
      { o: 0.00, c: '#1257c2' },
      { o: 0.35, c: '#2a7fde' },
      { o: 0.70, c: '#7ab4ea' },
      { o: 0.92, c: '#cae3f1' },
      { o: 1.00, c: '#e7f0f3' },
    ],
    hillBack:  '#4a7a32',
    hillMid:   '#6da53e',
    hillFront: '#86bd49',
    grassDark: '#3b6a1e',
    grassLight:'#82bc3f',
    grassTint: '#6fae34',
    cloudOpacity: 0.85,
    cloudTint:    '#ffffff',
    sun:    { x: 0.78, y: 0.10, r: 0.55, alpha: 0.18, color: '#ffffff' },
    horizonHaze: { color: '#dceaf2', alpha: 0.55 },
    shadowTint:  '#0c2d12',
  },
  morning: {
    name: 'Soft Morning',
    sky: [
      { o: 0.00, c: '#274d92' },
      { o: 0.35, c: '#5897d6' },
      { o: 0.70, c: '#b5d6ec' },
      { o: 0.92, c: '#f5d5b0' },
      { o: 1.00, c: '#f6dec0' },
    ],
    hillBack:  '#5c7c34',
    hillMid:   '#84ad44',
    hillFront: '#a0c958',
    grassDark: '#4a721f',
    grassLight:'#9bcb44',
    grassTint: '#8bbe3a',
    cloudOpacity: 0.75,
    cloudTint:    '#fff7eb',
    sun:    { x: 0.82, y: 0.50, r: 0.45, alpha: 0.35, color: '#fff0d2' },
    horizonHaze: { color: '#f5e1c4', alpha: 0.60 },
    shadowTint:  '#1a2d10',
  },
  golden: {
    name: 'Golden Hour',
    sky: [
      { o: 0.00, c: '#2a3c7e' },
      { o: 0.30, c: '#6c63a8' },
      { o: 0.55, c: '#d27a64' },
      { o: 0.80, c: '#f3b76e' },
      { o: 1.00, c: '#fbd591' },
    ],
    hillBack:  '#3b5224',
    hillMid:   '#5f7d2a',
    hillFront: '#7b9a35',
    grassDark: '#2f4517',
    grassLight:'#779334',
    grassTint: '#6c8a2c',
    cloudOpacity: 0.65,
    cloudTint:    '#ffd9a8',
    sun:    { x: 0.78, y: 0.66, r: 0.6, alpha: 0.55, color: '#ffd494' },
    horizonHaze: { color: '#f6c188', alpha: 0.70 },
    shadowTint:  '#221c0d',
  },
  twilight: {
    name: 'Twilight',
    sky: [
      { o: 0.00, c: '#0b1338' },
      { o: 0.35, c: '#283464' },
      { o: 0.65, c: '#6e4d83' },
      { o: 0.88, c: '#b4658d' },
      { o: 1.00, c: '#d28a8b' },
    ],
    hillBack:  '#23311e' ,
    hillMid:   '#384b2a',
    hillFront: '#4b6432',
    grassDark: '#1b2614',
    grassLight:'#3f5727',
    grassTint: '#3a5125',
    cloudOpacity: 0.55,
    cloudTint:    '#e6b4a7',
    sun:    { x: 0.18, y: 0.74, r: 0.6, alpha: 0.45, color: '#f6b78e' },
    horizonHaze: { color: '#d7889a', alpha: 0.60 },
    shadowTint:  '#070a1d',
  },
  meadow: {
    name: 'Verdant Noon',
    sky: [
      { o: 0.00, c: '#0e6bba' },
      { o: 0.40, c: '#3c95e0' },
      { o: 0.78, c: '#9ecae9' },
      { o: 1.00, c: '#cfe6ef' },
    ],
    hillBack:  '#3d7320',
    hillMid:   '#5a9c2c',
    hillFront: '#7ec03b',
    grassDark: '#2c5710',
    grassLight:'#86c63b',
    grassTint: '#6db028',
    cloudOpacity: 0.70,
    cloudTint:    '#f6fbff',
    sun:    { x: 0.65, y: 0.12, r: 0.5, alpha: 0.12, color: '#ffffff' },
    horizonHaze: { color: '#cfe6ef', alpha: 0.55 },
    shadowTint:  '#0a2207',
  },
};

// Hill compositions. Each layer is an array of [x, y] control points
// expressed in 0..1 of the viewport. Catmull-Rom-smoothed at render time.
// The order is back→front so later layers paint on top.
const HILL_COMPOSITIONS = {
  rolling: {
    name: 'Rolling',
    layers: [
      { fill: 'hillBack',  points: [[-0.05,0.66],[0.18,0.62],[0.32,0.63],[0.50,0.68],[0.72,0.72],[0.86,0.65],[1.05,0.68]] },
      { fill: 'hillMid',   points: [[-0.05,0.80],[0.22,0.66],[0.46,0.64],[0.63,0.75],[0.80,0.83],[0.93,0.74],[1.05,0.77]] },
      { fill: 'hillFront', points: [[-0.05,0.88],[0.30,0.81],[0.58,0.88],[0.82,0.85],[1.05,0.86]] },
    ],
    horizonY: 0.87,
  },
  layered: {
    name: 'Layered',
    layers: [
      { fill: 'hillBack',  points: [[-0.05,0.58],[0.10,0.52],[0.28,0.56],[0.45,0.50],[0.62,0.55],[0.80,0.49],[1.05,0.55]] },
      { fill: 'hillMid',   points: [[-0.05,0.72],[0.18,0.62],[0.38,0.66],[0.58,0.60],[0.78,0.68],[1.05,0.66]] },
      { fill: 'hillFront', points: [[-0.05,0.82],[0.22,0.76],[0.48,0.80],[0.72,0.74],[1.05,0.80]] },
    ],
    horizonY: 0.83,
  },
  distant: {
    name: 'Distant',
    layers: [
      { fill: 'hillBack',  points: [[-0.05,0.78],[0.20,0.76],[0.40,0.77],[0.60,0.75],[0.80,0.78],[1.05,0.77]] },
      { fill: 'hillMid',   points: [[-0.05,0.86],[0.25,0.82],[0.50,0.85],[0.75,0.83],[1.05,0.86]] },
      { fill: 'hillFront', points: [[-0.05,0.92],[0.35,0.90],[0.65,0.92],[1.05,0.91]] },
    ],
    horizonY: 0.92,
  },
  dunes: {
    name: 'Dunes',
    layers: [
      { fill: 'hillBack',  points: [[-0.05,0.72],[0.12,0.66],[0.34,0.70],[0.55,0.62],[0.78,0.71],[1.05,0.66]] },
      { fill: 'hillMid',   points: [[-0.05,0.82],[0.20,0.72],[0.42,0.78],[0.66,0.70],[0.88,0.78],[1.05,0.74]] },
      { fill: 'hillFront', points: [[-0.05,0.90],[0.28,0.82],[0.55,0.88],[0.85,0.82],[1.05,0.88]] },
    ],
    horizonY: 0.89,
  },
};

// Aspect-ratio presets. base{W,H} is the viewBox the scene is composed in;
// export size is base × resolution-scale.
const ASPECTS = {
  '16:9':   { name: '16:9 · Desktop',   w: 1920, h: 1080 },
  '21:9':   { name: '21:9 · Ultrawide', w: 2520, h: 1080 },
  '4:3':    { name: '4:3 · Classic',    w: 1600, h: 1200 },
  '1:1':    { name: '1:1 · Square',     w: 1500, h: 1500 },
  '9:16':   { name: '9:16 · Mobile',    w: 1170, h: 2080 },
  '9:19.5': { name: '9:19.5 · iPhone',  w: 1170, h: 2532 },
};

// Resolution multipliers for export.
const RES_SCALES = [
  { id: '1x',   label: '1× · Native',  scale: 1 },
  { id: '2x',   label: '2× · Retina',  scale: 2 },
  { id: '4k',   label: '4K (≈2×)',     scale: 2 },
  { id: '5k',   label: '5K (≈2.7×)',   scale: 2.7 },
  { id: '8k',   label: '8K (4×)',      scale: 4 },
];

Object.assign(window, { TOD_PRESETS, HILL_COMPOSITIONS, ASPECTS, RES_SCALES });
