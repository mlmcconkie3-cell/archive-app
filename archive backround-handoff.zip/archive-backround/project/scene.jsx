// scene.jsx — the landscape itself.
// Single inline <svg> so it scales infinitely and serializes cleanly for
// high-resolution PNG export. All texture is procedural (feTurbulence +
// gradients); no raster assets.

// Catmull-Rom → cubic Bezier through pts. Endpoints duplicate so the curve
// doesn't blow off-frame at the edges.
function smoothPath(pts) {
  if (!pts.length) return '';
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${c1x.toFixed(2)} ${c1y.toFixed(2)} ${c2x.toFixed(2)} ${c2y.toFixed(2)} ${p2[0].toFixed(2)} ${p2[1].toFixed(2)}`;
  }
  return d;
}

function hillPath(points, W, H) {
  const scaled = points.map(([x, y]) => [x * W, y * H]);
  // Pin the bottom corners outside the frame so anti-alias never reveals
  // a hairline under the foreground.
  const head = `M -10 ${H + 20}`;
  const top = smoothPath(scaled).replace(/^M[^C]+/, ' L ' + scaled[0][0].toFixed(2) + ' ' + scaled[0][1].toFixed(2));
  return head + top + ` L ${W + 10} ${H + 20} Z`;
}

// ─── Subcomponents ──────────────────────────────────────────────────────────

function SkyGradient({ tod, id }) {
  return (
    <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
      {tod.sky.map((s, i) => (
        <stop key={i} offset={s.o} stopColor={s.c} />
      ))}
    </linearGradient>
  );
}

function Sun({ tod, W, H }) {
  const cx = tod.sun.x * W;
  const cy = tod.sun.y * H;
  const r = tod.sun.r * Math.max(W, H);
  return (
    <>
      <defs>
        <radialGradient id="sunGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%"  stopColor={tod.sun.color} stopOpacity={tod.sun.alpha} />
          <stop offset="35%" stopColor={tod.sun.color} stopOpacity={tod.sun.alpha * 0.45} />
          <stop offset="100%" stopColor={tod.sun.color} stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cy} r={r} fill="url(#sunGlow)" />
    </>
  );
}

function Clouds({ tod, density, W, H, cloudFreqX = 0.0035, cloudFreqY = 0.018 }) {
  // Threshold turbulence into wispy bands. Higher density = lower threshold
  // (more cloud pixels survive), shifted via colorMatrix offset.
  const thresholdShift = -2.4 + density * 2.6; // density 0..1
  const baseY = 0;
  const skyH = H * 0.95;
  return (
    <>
      <defs>
        <filter id="cloudA" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency={`${cloudFreqX} ${cloudFreqY}`}
                        numOctaves="3" seed="7" />
          <feColorMatrix values={`0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 5 ${thresholdShift}`} />
          <feGaussianBlur stdDeviation="0.6" />
        </filter>
        <filter id="cloudB" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency={`${cloudFreqX * 1.8} ${cloudFreqY * 1.3}`}
                        numOctaves="4" seed="11" />
          <feColorMatrix values={`0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 0 1
                                  0 0 0 4.5 ${thresholdShift - 0.3}`} />
          <feGaussianBlur stdDeviation="0.4" />
        </filter>
        <linearGradient id="cloudFade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#fff" stopOpacity="0.6" />
          <stop offset="55%"  stopColor="#fff" stopOpacity="1" />
          <stop offset="100%" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <mask id="cloudMask">
          <rect x="0" y={baseY} width={W} height={skyH} fill="url(#cloudFade)" />
        </mask>
      </defs>
      <g mask="url(#cloudMask)" style={{ opacity: tod.cloudOpacity, mixBlendMode: 'screen' }}>
        <rect x="0" y={baseY} width={W} height={skyH} fill={tod.cloudTint} filter="url(#cloudA)" />
        <rect x="0" y={baseY} width={W} height={skyH} fill={tod.cloudTint} filter="url(#cloudB)"
              style={{ opacity: 0.55 }} />
      </g>
    </>
  );
}

function HorizonHaze({ tod, horizonY, W, H }) {
  const top = (horizonY - 0.18) * H;
  const bot = (horizonY + 0.02) * H;
  return (
    <>
      <defs>
        <linearGradient id="horizonHaze" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor={tod.horizonHaze.color} stopOpacity="0" />
          <stop offset="80%"  stopColor={tod.horizonHaze.color} stopOpacity={tod.horizonHaze.alpha} />
          <stop offset="100%" stopColor={tod.horizonHaze.color} stopOpacity={tod.horizonHaze.alpha} />
        </linearGradient>
      </defs>
      <rect x="0" y={top} width={W} height={bot - top} fill="url(#horizonHaze)" />
    </>
  );
}

function Hills({ tod, composition, W, H }) {
  return (
    <>
      <defs>
        {/* Subtle hill-side shading: darker on left flanks, lighter on tops */}
        <linearGradient id="hillShadeBack" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#fff" stopOpacity="0.10" />
          <stop offset="40%"  stopColor="#fff" stopOpacity="0" />
          <stop offset="100%" stopColor={tod.shadowTint} stopOpacity="0.10" />
        </linearGradient>
        <linearGradient id="hillShadeMid" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#fff" stopOpacity="0.16" />
          <stop offset="50%"  stopColor="#fff" stopOpacity="0" />
          <stop offset="100%" stopColor={tod.shadowTint} stopOpacity="0.20" />
        </linearGradient>
        <linearGradient id="hillShadeFront" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#fff" stopOpacity="0.20" />
          <stop offset="60%"  stopColor="#fff" stopOpacity="0" />
          <stop offset="100%" stopColor={tod.shadowTint} stopOpacity="0.30" />
        </linearGradient>
        {/* Soft side-lighting that follows the sun's horizontal position */}
        <radialGradient id="hillKick" cx={tod.sun.x} cy={Math.max(0.55, tod.sun.y)} r="0.7">
          <stop offset="0%"  stopColor={tod.sun.color} stopOpacity="0.30" />
          <stop offset="60%" stopColor={tod.sun.color} stopOpacity="0" />
        </radialGradient>
        {/* Grass-side micro-texture filter, applied per layer */}
        <filter id="hillFuzz" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.012 0.18" numOctaves="2" seed="3" />
          <feColorMatrix values="0 0 0 0 0
                                 0 0 0 0 0
                                 0 0 0 0 0
                                 0 0 0 0.10 0" />
          <feComposite in2="SourceGraphic" operator="in" />
        </filter>
      </defs>

      {composition.layers.map((layer, i) => {
        const d = hillPath(layer.points, W, H);
        const shade = ['hillShadeBack', 'hillShadeMid', 'hillShadeFront'][i] || 'hillShadeFront';
        return (
          <g key={i}>
            <path d={d} fill={tod[layer.fill]} />
            <path d={d} fill={`url(#${shade})`} />
            <path d={d} fill="url(#hillKick)" style={{ mixBlendMode: 'screen', opacity: 0.7 }} />
            <path d={d} filter="url(#hillFuzz)" />
          </g>
        );
      })}
    </>
  );
}

function GrassField({ tod, horizonY, W, H }) {
  const top = horizonY * H;
  const fieldH = H - top;
  return (
    <>
      <defs>
        <linearGradient id="grassFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor={tod.grassDark} />
          <stop offset="50%"  stopColor={tod.grassTint} />
          <stop offset="100%" stopColor={tod.grassLight} />
        </linearGradient>
        {/* Grass blades — anisotropic noise stretched vertically */}
        <filter id="grassBlades" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.018 0.8" numOctaves="3" seed="5" />
          <feColorMatrix values="0 0 0 0 0.25
                                 0 0 0 0 0.45
                                 0 0 0 0 0.15
                                 0 0 0 0.55 -0.2" />
        </filter>
        {/* Brighter highlight blades — sparser */}
        <filter id="grassHi" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.025 1.2" numOctaves="2" seed="9" />
          <feColorMatrix values="0 0 0 0 0.75
                                 0 0 0 0 0.95
                                 0 0 0 0 0.40
                                 0 0 0 0.4 -0.25" />
        </filter>
        {/* Shadow patches — broad low-freq noise */}
        <filter id="grassShadow" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.004 0.012" numOctaves="2" seed="2" />
          <feColorMatrix values="0 0 0 0 0
                                 0 0 0 0 0
                                 0 0 0 0 0
                                 0 0 0 0.5 -0.15" />
        </filter>
        <linearGradient id="grassVignette" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#000" stopOpacity="0" />
          <stop offset="100%" stopColor="#000" stopOpacity="0.18" />
        </linearGradient>
        <radialGradient id="grassKick" cx={tod.sun.x} cy="0.1" r="0.9">
          <stop offset="0%"  stopColor={tod.sun.color} stopOpacity="0.40" />
          <stop offset="70%" stopColor={tod.sun.color} stopOpacity="0" />
        </radialGradient>
      </defs>

      <g>
        <rect x="0" y={top} width={W} height={fieldH} fill="url(#grassFill)" />
        <rect x="0" y={top} width={W} height={fieldH} filter="url(#grassShadow)"
              style={{ mixBlendMode: 'multiply', opacity: 0.55 }} />
        <rect x="0" y={top} width={W} height={fieldH} filter="url(#grassBlades)"
              style={{ mixBlendMode: 'multiply', opacity: 0.6 }} />
        <rect x="0" y={top} width={W} height={fieldH} filter="url(#grassHi)"
              style={{ mixBlendMode: 'screen', opacity: 0.45 }} />
        <rect x="0" y={top - 6} width={W} height={fieldH + 6} fill="url(#grassKick)"
              style={{ mixBlendMode: 'screen', opacity: 0.8 }} />
        <rect x="0" y={top} width={W} height={fieldH} fill="url(#grassVignette)" />
        {/* Sharp horizon line / earth seam */}
        <rect x="0" y={top - 1} width={W} height="1.5" fill={tod.shadowTint} opacity="0.35" />
      </g>
    </>
  );
}

function Vignette({ W, H, amount = 0.18 }) {
  return (
    <>
      <defs>
        <radialGradient id="vig" cx="50%" cy="55%" r="65%">
          <stop offset="60%"  stopColor="#000" stopOpacity="0" />
          <stop offset="100%" stopColor="#000" stopOpacity={amount} />
        </radialGradient>
      </defs>
      <rect x="0" y="0" width={W} height={H} fill="url(#vig)" />
    </>
  );
}

function Grain({ W, H, amount = 0.05 }) {
  return (
    <>
      <defs>
        <filter id="grainNoise">
          <feTurbulence type="fractalNoise" baseFrequency="1.6" numOctaves="2" seed="13" />
          <feColorMatrix values="0 0 0 0 1
                                 0 0 0 0 1
                                 0 0 0 0 1
                                 0 0 0 0.5 -0.25" />
        </filter>
      </defs>
      <rect x="0" y="0" width={W} height={H} filter="url(#grainNoise)"
            style={{ mixBlendMode: 'overlay', opacity: amount }} />
    </>
  );
}

// ─── Scene ──────────────────────────────────────────────────────────────────

function Scene({ todKey, hillKey, aspect, cloudDensity, sunOn, vignette, grain,
                 svgRef, exporting }) {
  const tod = TOD_PRESETS[todKey];
  const comp = HILL_COMPOSITIONS[hillKey];
  const { w: W, h: H } = ASPECTS[aspect];
  return (
    <svg ref={svgRef}
         xmlns="http://www.w3.org/2000/svg"
         viewBox={`0 0 ${W} ${H}`}
         preserveAspectRatio="xMidYMid slice"
         style={{ display: 'block', width: '100%', height: '100%' }}>
      <defs>
        <SkyGradient tod={tod} id="skyGrad" />
      </defs>
      <rect x="0" y="0" width={W} height={H} fill="url(#skyGrad)" />
      {sunOn && <Sun tod={tod} W={W} H={H} />}
      <Clouds tod={tod} density={cloudDensity} W={W} H={H} />
      <HorizonHaze tod={tod} horizonY={comp.horizonY} W={W} H={H} />
      <Hills tod={tod} composition={comp} W={W} H={H} />
      <GrassField tod={tod} horizonY={comp.horizonY} W={W} H={H} />
      {vignette > 0 && <Vignette W={W} H={H} amount={vignette} />}
      {grain > 0 && <Grain W={W} H={H} amount={grain} />}
    </svg>
  );
}

Object.assign(window, { Scene, smoothPath, hillPath });
