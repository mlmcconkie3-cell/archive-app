// archive-app.jsx — glassy redesign of the Archive "Add" screen.
// Real glassmorphism: backdrop-filter blur, layered inner highlight,
// soft outer shadow, subtle diagonal sheen. Solid contrasting bg.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "bg": "teal",
  "blur": 36,
  "glassAlpha": 0.08,
  "sheen": true,
  "ringHighlight": true,
  "noise": 0.06,
  "accent": "#e98a64",
  "bgTint": 0.55
} /*EDITMODE-END*/;

// Curated background palette — each is a *solid* color picked to make a
// translucent white glass card read with depth.
const BGS = {
  teal: { name: 'Deep Teal', color: '#0c2a27', fg: '#f4ece2', dim: 'rgba(244,236,226,0.55)', kind: 'dark' },
  forest: { name: 'Forest', color: '#13231a', fg: '#f0eee2', dim: 'rgba(240,238,226,0.55)', kind: 'dark' },
  plum: { name: 'Plum', color: '#1e1226', fg: '#f3e8ef', dim: 'rgba(243,232,239,0.55)', kind: 'dark' },
  cobalt: { name: 'Cobalt Night', color: '#0e1a32', fg: '#e8edf5', dim: 'rgba(232,237,245,0.55)', kind: 'dark' },
  graphite: { name: 'Graphite', color: '#17181b', fg: '#ececec', dim: 'rgba(236,236,236,0.55)', kind: 'dark' },
  cocoa: { name: 'Cocoa', color: '#241813', fg: '#f5e8de', dim: 'rgba(245,232,222,0.55)', kind: 'dark' },
  bone: { name: 'Warm Bone', color: '#efe7da', fg: '#1a1612', dim: 'rgba(26,22,18,0.60)', kind: 'light' }
};

function Logo() {
  return (
    <div className="brand">
      <span>ARCHIVE</span>
    </div>);

}

function NavBar({ fg }) {
  return (
    <header className="nav" data-screen-label="Archive · Add">
      <Logo />
      <div className="nav-right">
        <button className="settings-btn" aria-label="Settings">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"
               strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
          </svg>
          <svg className="caret" viewBox="0 0 10 6" width="9" height="6" fill="currentColor">
            <path d="M0 0h10L5 6z" />
          </svg>
        </button>
      </div>
    </header>);

}

function StatRow() {
  return (
    <div className="glass card stat">
      <div className="stat-l">
        <div className="stat-eyebrow">YOUR ARCHIVE</div>
        <div className="stat-sub">8 items</div>
      </div>
      <div className="stat-r">$38,779</div>
    </div>);

}

function PromptCard({ accent }) {
  return (
    <div className="glass card prompt">
      <div className="prompt-placeholder" style={{ color: "rgb(207, 232, 210)" }}>
        Describe what you just got… or attach a photo below
      </div>
      <div className="prompt-actions">
        <div className="prompt-actions-l">
          <button className="icon-btn" aria-label="Upload">
            <svg viewBox="0 0 16 16" width="14" height="14" fill="none"
            stroke="currentColor" strokeWidth="1.6"
            strokeLinecap="round" strokeLinejoin="round">
              <path d="M8 11.5V3.5" />
              <path d="M4.5 7L8 3.5L11.5 7" />
              <path d="M3 12.5h10" />
            </svg>
          </button>
          <button className="chip" style={{ '--chip-bg': accent, backgroundColor: "rgba(99, 184, 118, 0.424)" }}>
            <span className="chip-emoji">📦</span>
            <span>My Collection</span>
            <svg viewBox="0 0 10 6" width="9" height="6" fill="currentColor">
              <path d="M0 0h10L5 6z" />
            </svg>
          </button>
        </div>
        <button className="send-btn" aria-label="Send" style={{ backgroundColor: "rgb(63, 166, 47)" }}>
          <svg viewBox="0 0 16 16" width="14" height="14" fill="none"
          stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ stroke: "rgb(14, 42, 81)" }}>
            <path d="M3 8h10" />
            <path d="M9 4l4 4-4 4" />
          </svg>
        </button>
      </div>
    </div>);

}

function ActionCard({ emoji, title, sub }) {
  return (
    <div className="glass card action">
      <span className="action-emoji">{emoji}</span>
      <div className="action-text">
        <div className="action-title">{title}</div>
        <div className="action-sub">{sub}</div>
      </div>
    </div>);

}

function TabBar() {
  const tabs = [
  { id: 'add', label: 'ADD', icon:
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor"
    strokeWidth="1.6" strokeLinecap="round">
        <circle cx="12" cy="12" r="9.5" />
        <path d="M12 7.5v9M7.5 12h9" />
      </svg>,
    active: true },
  { id: 'collection', label: 'COLLECTION', icon:
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor"
    strokeWidth="1.6" strokeLinecap="round">
        <rect x="3.5" y="3.5" width="7" height="7" rx="1" />
        <rect x="13.5" y="3.5" width="7" height="7" rx="1" />
        <rect x="3.5" y="13.5" width="7" height="7" rx="1" />
        <rect x="13.5" y="13.5" width="7" height="7" rx="1" />
      </svg>
  },
  { id: 'dashboard', label: 'DASHBOARD', icon:
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor"
    strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3.5 11L12 4l8.5 7" />
        <path d="M5.5 10v10h13V10" />
      </svg>
  },
  { id: 'profile', label: 'PROFILE', icon:
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor"
    strokeWidth="1.6" strokeLinecap="round">
        <circle cx="12" cy="8.5" r="3.6" />
        <path d="M5 20c1.4-3.3 4-5 7-5s5.6 1.7 7 5" />
      </svg>
  }];

  return (
    <nav className="tabbar">
      <div className="tabbar-inner">
        {tabs.map((tab) =>
        <button key={tab.id} className={'tab' + (tab.active ? ' active' : '')}>
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        )}
      </div>
    </nav>);

}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const palette = BGS[t.bg];

  // Inject CSS variables for the live theme. Keep them in a style tag so they
  // also flow into the glass mixins.
  const cssVars = {
    '--bg': palette.color,
    '--fg': palette.fg,
    '--fg-dim': palette.dim,
    '--accent': t.accent,
    '--glass-blur': t.blur + 'px',
    '--glass-alpha': t.glassAlpha,
    '--glass-alpha-hi': Math.min(0.18, t.glassAlpha * 2.2),
    '--ring-alpha': t.ringHighlight ? 0.22 : 0.10,
    '--noise-alpha': t.noise,
    '--bg-tint': t.bgTint
  };

  const swatches = Object.keys(BGS).map((k) => BGS[k].color);
  const bgKeys = Object.keys(BGS);

  return (
    <div className={'app ' + palette.kind} style={cssVars} data-screen-label="Archive · Add">
      {/* SVG noise pattern used by .glass for a subtle frosted texture */}
      <svg width="0" height="0" style={{ position: 'absolute' }}>
        <filter id="glassNoise">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" />
          <feColorMatrix values="0 0 0 0 1
                                 0 0 0 0 1
                                 0 0 0 0 1
                                 0 0 0 0.5 -0.25" />


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          


          
        </filter>
      </svg>

      <div className="bg-photo" aria-hidden="true" />

      <NavBar />

      <main className="content">
        <h1 className="hero">Ready to Archive</h1>
        <p className="hero-sub">What did you just get?</p>

        <div className="stack">
          <StatRow />
          {t.sheen && <div className="sr-spacer" />}
          <PromptCard accent={t.accent} />
          <div className="action-row">
            <ActionCard emoji="📸" title="Take a photo" sub="Opens your camera" />
            <ActionCard emoji="🖼️" title="Upload photo" sub="From your library" />
          </div>
        </div>
      </main>

      <TabBar />

      <TweaksPanel title="Archive theme">
        <TweakSection label="Background" />
        <TweakColor
          label="Tint"
          value={palette.color}
          options={swatches}
          onChange={(color) => {
            const k = bgKeys.find((b) => BGS[b].color.toLowerCase() === color.toLowerCase());
            if (k) setTweak('bg', k);
          }} />
        
        <div className="tweak-readout">{palette.name} · photo</div>
        <TweakSlider label="Tint strength" value={Math.round(t.bgTint * 100)}
        min={0} max={90} step={5} unit="%"
        onChange={(v) => setTweak('bgTint', v / 100)} />

        <TweakSection label="Glass" />
        <TweakSlider label="Blur" value={t.blur} min={8} max={60} step={2} unit="px"
        onChange={(v) => setTweak('blur', v)} />
        <TweakSlider label="Fill" value={Math.round(t.glassAlpha * 100)}
        min={2} max={20} step={1} unit="%"
        onChange={(v) => setTweak('glassAlpha', v / 100)} />
        <TweakToggle label="Edge highlight" value={t.ringHighlight}
        onChange={(v) => setTweak('ringHighlight', v)} />
        <TweakToggle label="Inner sheen" value={t.sheen}
        onChange={(v) => setTweak('sheen', v)} />
        <TweakSlider label="Frost noise" value={Math.round(t.noise * 100)}
        min={0} max={20} step={1} unit="%"
        onChange={(v) => setTweak('noise', v / 100)} />

        <TweakSection label="Accent" />
        <TweakColor label="Chip"
        value={t.accent}
        options={['#e98a64', '#d97757', '#f5b94a', '#7fbf6f', '#8bb3e0', '#c79bd9']}
        onChange={(v) => setTweak('accent', v)} />
      </TweaksPanel>
    </div>);

}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);